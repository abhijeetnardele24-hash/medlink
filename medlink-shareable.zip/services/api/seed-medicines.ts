import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as fs from 'fs';
import * as path from 'path';
import { medicines } from "./src/db/schema";
import { eq } from "drizzle-orm";

// Load .env manually
const envPath = path.join(process.cwd(), '.env');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf-8');
  envContent.split('\n').forEach(line => {
    const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
    if (match) {
      const key = match[1];
      let value = match[2] || '';
      if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
      process.env[key] = value;
    }
  });
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

const db = drizzle(pool);

// A highly curated list of 10 popular Indian medicines for the showcase.
const seedData = [
  {
    name: "Dolo 650 Tablet",
    genericName: "Paracetamol (650mg)",
    description: "Used to treat fever and mild to moderate pain.",
    imageUrl: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80", // White tablets
    composition: "Paracetamol 650mg",
    dosageForm: "Tablet",
    manufacturer: "Micro Labs Ltd",
    price: 33,
    stockQuantity: 500,
    prescriptionTier: "otc",
    category: "Fever & Pain",
  },
  {
    name: "Augmentin 625 Duo Tablet",
    genericName: "Amoxycillin (500mg) + Clavulanic Acid (125mg)",
    description: "A penicillin-type of antibiotic that helps your body fight infections caused by bacteria.",
    imageUrl: "https://images.unsplash.com/photo-1628771065518-0d82f1938462?w=500&q=80", // Capsule/Antibiotic look
    composition: "Amoxycillin 500mg + Clavulanic Acid 125mg",
    dosageForm: "Tablet",
    manufacturer: "GlaxoSmithKline Pharmaceuticals Ltd",
    price: 204,
    stockQuantity: 150,
    prescriptionTier: "schedule_h",
    category: "Antibiotics",
  },
  {
    name: "Pan-D Capsule PR",
    genericName: "Pantoprazole (40mg) + Domperidone (30mg)",
    description: "A prescription medicine used to treat gastroesophageal reflux disease (Acid reflux) and peptic ulcer disease.",
    imageUrl: "https://images.unsplash.com/photo-1631549916768-4119b2e5f926?w=500&q=80", // Capsules
    composition: "Pantoprazole 40mg + Domperidone 30mg",
    dosageForm: "Capsule PR",
    manufacturer: "Alkem Laboratories Ltd",
    price: 199,
    stockQuantity: 200,
    prescriptionTier: "schedule_h",
    category: "Stomach Care",
  },
  {
    name: "Allegra 120mg Tablet",
    genericName: "Fexofenadine (120mg)",
    description: "An anti-allergy medicine used in the treatment of allergic symptoms such as runny nose, congestion or stuffiness, sneezing, itching, swelling, and watery eyes.",
    imageUrl: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80", // White tablets
    composition: "Fexofenadine 120mg",
    dosageForm: "Tablet",
    manufacturer: "Sanofi India Ltd",
    price: 218,
    stockQuantity: 300,
    prescriptionTier: "otc",
    category: "Allergy",
  },
  {
    name: "Thyronorm 50mcg Tablet",
    genericName: "Thyroxine (50mcg)",
    description: "Used to treat an underactive thyroid gland (hypothyroidism).",
    imageUrl: "https://images.unsplash.com/photo-1550572017-edb79998816c?w=500&q=80", // Small white tablets in bottle
    composition: "Thyroxine 50mcg",
    dosageForm: "Tablet",
    manufacturer: "Abbott",
    price: 152,
    stockQuantity: 100,
    prescriptionTier: "schedule_h",
    category: "Thyroid Care",
  },
  {
    name: "Ecosprin 75 Tablet",
    genericName: "Aspirin (75mg)",
    description: "An antiplatelet medicine used to prevent heart attacks, strokes and heart-related chest pain (angina).",
    imageUrl: "https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?w=500&q=80", // Generic pill
    composition: "Aspirin 75mg",
    dosageForm: "Tablet",
    manufacturer: "USV Ltd",
    price: 5,
    stockQuantity: 1000,
    prescriptionTier: "schedule_h",
    category: "Heart Care",
  },
  {
    name: "Corex DX Syrup",
    genericName: "Chlorpheniramine Maleate (4mg/5ml) + Dextromethorphan Hydrobromide (10mg/5ml)",
    description: "Used in the treatment of dry cough.",
    imageUrl: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500&q=80", // Syrup bottle
    composition: "Chlorpheniramine Maleate + Dextromethorphan Hydrobromide",
    dosageForm: "Syrup",
    manufacturer: "Pfizer Ltd",
    price: 110,
    stockQuantity: 250,
    prescriptionTier: "otc",
    category: "Cough & Cold",
  },
  {
    name: "Volini Pain Relief Gel",
    genericName: "Diclofenac diethylamine (1.16% w/w) + Linseed Oil (3% w/w) + Methyl Salicylate (10% w/w) + Menthol (5% w/w)",
    description: "A pain relief gel which provides effective relief from muscle pain, strains, sprains, spasms and cramps.",
    imageUrl: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=500&q=80", // Tube/Cream
    composition: "Diclofenac + Linseed Oil + Methyl Salicylate + Menthol",
    dosageForm: "Gel",
    manufacturer: "Sun Pharmaceutical Industries Ltd",
    price: 185,
    stockQuantity: 150,
    prescriptionTier: "otc",
    category: "Pain Relief",
  },
  {
    name: "Calpol 250mg Peadiatric Oral Suspension",
    genericName: "Paracetamol (250mg/5ml)",
    description: "Used to treat mild to moderate pain and relieve fever in children.",
    imageUrl: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500&q=80", // Syrup bottle
    composition: "Paracetamol 250mg/5ml",
    dosageForm: "Oral Suspension",
    manufacturer: "GlaxoSmithKline Pharmaceuticals Ltd",
    price: 43,
    stockQuantity: 120,
    prescriptionTier: "otc",
    category: "Pediatric",
  },
  {
    name: "Shelcal 500 Tablet",
    genericName: "Calcium Carbonate (500mg) + Vitamin D3 (250IU)",
    description: "A calcium and vitamin D3 supplement used to prevent or treat low blood calcium levels.",
    imageUrl: "https://images.unsplash.com/photo-1550572017-edb79998816c?w=500&q=80", // Supplement bottle
    composition: "Calcium Carbonate + Vitamin D3",
    dosageForm: "Tablet",
    manufacturer: "Torrent Pharmaceuticals Ltd",
    price: 119,
    stockQuantity: 400,
    prescriptionTier: "otc",
    category: "Supplements",
  }
];

async function main() {
  console.log("Starting to seed rich medicine data...");
  
  let insertedCount = 0;
  for (const med of seedData) {
    try {
      // Check if medicine already exists
      const existing = await db.select().from(medicines).where(eq(medicines.name, med.name)).limit(1);
      
      if (existing.length > 0) {
        // Update existing
        await db.update(medicines).set({
          description: med.description,
          imageUrl: med.imageUrl,
          composition: med.composition,
          dosageForm: med.dosageForm,
          manufacturer: med.manufacturer,
          price: med.price,
          category: med.category,
          genericName: med.genericName,
          prescriptionTier: med.prescriptionTier as any
        }).where(eq(medicines.id, existing[0].id));
        console.log(`Updated: ${med.name}`);
      } else {
        // Insert new
        await db.insert(medicines).values({ ...med, prescriptionTier: med.prescriptionTier as any });
        console.log(`Inserted: ${med.name}`);
      }
      insertedCount++;
    } catch (error) {
      console.error(`Error processing ${med.name}:`, error);
    }
  }

  console.log(`\nSuccessfully processed ${insertedCount} showcase medicines.`);
  console.log("🎉 Rich Seeding Complete!");
  
  process.exit(0);
}

main().catch((err) => {
  console.error("Fatal Error:", err);
  process.exit(1);
});

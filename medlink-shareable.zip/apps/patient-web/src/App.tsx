import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { Dashboard } from './pages/Dashboard';
import { DoctorProfile } from './pages/DoctorProfile';
import { History } from './pages/History';
import { HealthProfile } from './pages/HealthProfile';
import { MedicalRecords } from './pages/MedicalRecords';
import { Consultation } from './pages/Consultation';
import { Triage } from './pages/Triage';
import { Layout } from './components/Layout';
import { IncomingCallModal } from './components/IncomingCallModal';
import './index.css';

function App() {
  return (
    <AuthProvider>
      <Router>
        <IncomingCallModal />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          
          <Route element={<ProtectedRoute />}>
            <Route element={<Layout />}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/doctor/:id" element={<DoctorProfile />} />
              <Route path="/history" element={<History />} />
              <Route path="/triage" element={<Triage />} />
              <Route path="/profile" element={<HealthProfile />} />
              <Route path="/medical-records" element={<MedicalRecords />} />
            </Route>
            {/* Consultation is full screen, no sidebar */}
            <Route path="/consultation/:id" element={<Consultation />} />
          </Route>
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
